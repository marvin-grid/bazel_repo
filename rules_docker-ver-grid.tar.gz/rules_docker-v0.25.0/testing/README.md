E2E tests
---------

To run all e2e tests, use the command
```
$ ./e2e.sh
```

To run a single test, use the command
```
$ ./e2e.sh <test-name>
```

