const lib = require('./nodejs_image_lib');

console.log(lib.message());
console.log(process.argv.slice(2))
